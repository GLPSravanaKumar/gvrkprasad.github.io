document.addEventListener('DOMContentLoaded', () => {
    console.log('GLPS Career Guidance site is ready!');
});
